sass --style=compressed --sourcemap=none --no-cache main.scss:main.css
sass --style=compressed --sourcemap=none --no-cache classic.scss:classic.css
sass --style=compressed --sourcemap=none --no-cache blue.scss:blue.css
